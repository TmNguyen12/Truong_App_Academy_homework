<h1>Interactive drunken circles</h1>

<h3>Instructions to Run Locally</h3>

Navigate to the project directory in your terminal.
<br>

$ open index.html

<p>The differences from the original can be found with the added event listener in the window.Game function as well as in the moveCircle and moveRandom functions.</p>
